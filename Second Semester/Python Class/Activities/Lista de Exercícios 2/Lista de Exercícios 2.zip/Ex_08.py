# 8. (Desafio) Faça um programa que apresenta a tabuada completa de 1 a 10.

import os
os.system('cls') # Limpar o Terminal .
os.system('color 3') # Mudança na cor das letras (Azul).

for x in range(1,11):
    print("")
    print("▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄")
    print("▌►  Tabuada %2d ◄▐" %(x))

    for y in range(0,11):
        print("▌ %2d * %2d = %3d ▐" %(x, y, (x*y)))
        
        if y == 10:
            print("▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀")

#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;
#include <windows.h> // Colocar T�tulo;

/*

Dado um valor n, exiba uma contagem regressiva do valor at� atingir zero.
                        Por exemplo: n = 10,

resultado = 10 9 8 7 6 5 4 3 2 1 0
Observa��o: Utilizar o comando de repeti��o /for/

*/

void Cabecalho(){
    system("cls");
    system("color 3");

    // Cabe�alho com Nome, R.A. e Campus.
    printf("  Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT  \n");
    printf("------------------------------------------------------------------\n");
    // T�tulo do Programa.
    printf("\t=============================================================\n");
    printf("\t|                  Contagem Regressiva                      |\n");
    printf("\t=============================================================\n");
}

int main(){
    setlocale(LC_ALL,""); // Trocando Idioma: Portugu�s.
    SetConsoleTitle("Contagem Regressiva - Desenvolvido por: Vinicius Carvalho - 74.381"); // T�tulo do Programa.
    Cabecalho();

    // V�riaveis
    int timer, i;

    printf("\n\n > Digite o TIMER desejado: ");
    scanf("%d", &timer);
    printf("\n");

    for(i=timer; i>=0; i--){
        printf("\n\t\t> %d <", i);
        sleep(1);
    }

    printf("\n\n\t // TEMPO ESGOTADO // \n\n");

    getch();
    return 0;
}

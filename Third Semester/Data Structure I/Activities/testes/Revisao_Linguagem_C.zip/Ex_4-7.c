#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;
#include <windows.h> // Colocar T�tulo;

/*
A s�rie de Fibonacci � 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, ... Os dois primeiros termos s�o iguais a 1 e,
a partir do terceiro, o termo � dado pela soma dos dois termos anteriores.
Dado um n�mero n >= 3, exiba os n�meros da s�rie de Fibonacci at� n.
Por exemplo: n = 21, resultado = 1, 1, 2, 3, 5, 8, 13, 21

Observa��o: Utilizar o comando de repeti��o while
*/

void Cabecalho(){
    system("cls");
    system("color 3");

    // Cabe�alho com Nome, R.A. e Campus.
    printf("  Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT  \n");
    printf("------------------------------------------------------------------\n");
    // T�tulo do Programa.
    printf("\n\t=================================================================\n");
    printf("\t|                      S�rie de Fibonacci                       |\n");
    printf("\t=================================================================\n");
}

void Gerador_Serie(int valor){
    int contador=1, antes=0;

    printf("\n >  ");
    while(contador <= valor){
        printf("%d | ", contador);
        // Somando o valor atual com o anterior.
        contador = contador + antes;
        // Recuperando o valor anterior para usar em seguida.
        antes = contador-antes;
    }
    printf("  <\n\n");

}

int main(){
    setlocale(LC_ALL,""); // Trocando Idioma: Portugu�s.
    SetConsoleTitle("S�rie de Fibonacci - Desenvolvido por: Vinicius Carvalho - 74.381"); // T�tulo do Programa.
    Cabecalho();

    // Vari�veis.
    int numero, resultado;

    // Recebendo Entrada.
    printf("\n > Digite um n�mero: ");
    scanf("%d", &numero);

    Gerador_Serie(numero);

    getch();
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;

/*
Dada um temperatura em graus Fahrenheit, informe o valor correspondente em graus Celsius.

F�rmula: C = (F � 32) * (5 / 9)
Onde: C = Temperatura em graus Celsius, F = Temperatura em graus Fahrenheit
*/

void Cabecalho(){
    system("cls");
    system("color 3");
    // Cabe�alho com Nome, R.A. e Campus.
    printf("=================================================================\n");
    printf("| Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT |\n");
    printf("=================================================================\n\n");
}

float Conversor_Temperatura(float F){
    return((F - 32.0) * (5.0 / 9.0));
}

int main(){
    // Trocando Idioma: Portugu�s:
    setlocale(LC_ALL,"");
    Cabecalho();

    // Vari�veis:
    float fahrenheit;

    // Entrada de Dados:
    printf("\n> Digite a temperatura em graus Fahrenheit: ");
    scanf("%f", &fahrenheit);
    system("cls");

    // Processamento e Sa�da:
    Cabecalho();
    printf("\n\t> %.2f� Fahrenheit � equivalente �: %.2f� Celsius <\n\n", fahrenheit, Conversor_Temperatura(fahrenheit));

    getch();
    return 0;

}

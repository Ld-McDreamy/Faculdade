#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;

/*
Numa faculdade, os alunos com m�dia pelo menos 7,0 s�o aprovados, aqueles com m�dia
inferior a 3,0 s�o reprovados e os demais ficam de recupera��o. Dadas as duas notas de um
aluno, calcule sua m�dia (m�dia aritm�tica simples) e informe sua situa��o. Apresente como
sa�da a nota m�dia calculada e as mensagens relativas a situa��o final do aluno, a saber
�Aprovado�, �Reprovado� ou �Recupera��o�, respectivamente
*/

void Cabecalho(){
    system("cls");
    system("color 3");
    // Cabe�alho com Nome, R.A. e Campus.
    printf("=================================================================\n");
    printf("| Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT |\n");
    printf("=================================================================\n\n");
}

float Media_Aritmetica(float n1, float n2){
    return (n1+n2) / 2;
}

int main(){
    // Trocando Idioma: Portugu�s:
    setlocale(LC_ALL,"");
    Cabecalho();

    // Vari�veis:
    float nota1, nota2, media;

    // Recebendo entrada de Dados:
    printf("\n> Digite a primeira nota: ");
    scanf("%f", &nota1);
    printf("\n> Digite a segunda nota: ");
    scanf("%f", &nota2);

    media = Media_Aritmetica(nota1, nota2);

    // Condicional para checar as nota:
    if(media >= 7.0) printf("\n\n\t\t    > Aluno APROVADO <\n\t\t > Nota de M�dia: %.2f <\n\n", media);
    else if(media < 3) printf("\n\n\t\t   > Aluno REPROVADO <\n\t\t > Nota de M�dia: %.2f <\n\n", media);
    else printf("\n\n\t\t > Aluno de RECUPERA��O <\n\t\t > Nota de M�dia: %.2f <\n\n", media);

    getch();
    return 0;
}

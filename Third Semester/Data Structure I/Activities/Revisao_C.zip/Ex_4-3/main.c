#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;
#include <windows.h> // Colocar T�tulo;

/*

    Dado um ano, informe se ele � ou n�o bissexto.
    Dica: um ano � bissexto se � divis�vel por 4 mas n�o por 100.

*/

void Cabecalho(){
    system("cls");
    system("color 3");

    // Cabe�alho com Nome, R.A. e Campus.
    printf("  Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT  \n");
    printf("------------------------------------------------------------------\n");
    // T�tulo do Programa.
    printf("\n\t===================================================================\n");
    printf("\t|                       � OU N�O � BISSEXTO                       |\n");
    printf("\t===================================================================\n");
}

int main(){
    setlocale(LC_ALL,""); // Trocando Idioma: Portugu�s.
    SetConsoleTitle("Descubra Ano Bissexto - Desenvolvido por: Vinicius Carvalho - 74.381"); // T�tulo do Programa.
    Cabecalho();

    int ano;

    printf("\n\n > Digite um ano: ");
    scanf("%d", &ano);

    if((ano % 400 == 0) || (ano % 4 == 0 && ano % 100 != 0)) printf("\n\n\t\t\t > O ano de %d � BISSEXTO <\n\n", ano);
    else printf("\n\n\t\t\t > O ano de %d � N�O � BISSEXTO <\n\n", ano);


    getch();
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;
#include <windows.h> // Colocar Título;

/*
8 Em um banco, as contas são identificadas por números de até seis dígitos seguidos
de um dígito verificador (DV) também chamado de dígito de controle, calculado
conforme exemplificado a seguir. Dado um número de conta n, exiba o número de conta
completo correspondente (número + DV).

Exemplo: seja n = 7314 o número da conta.

1) Adicionamos os dígitos de n e obtemos a soma s = 4+1+3+7 = 15;
2) Calculamos o resto da divisão de s por 10 e obtemos o dígito d = 5.
Resultado: Número de conta completo: 007314−5

Observação: Utilizar o comando de repetição while
*/

void Cabecalho(){
    system("cls");
    system("color 3");

    // Cabeçalho com Nome, R.A. e Campus.
    printf("  Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT  \n");
    printf("------------------------------------------------------------------\n");
    // Título do Programa.
    printf("\n\t===================================================================\n");
    printf("\t|                  Gerador de Digito Verificador                  |\n");
    printf("\t===================================================================\n");
}

int Gerador_DV(int conta){
    int numero[6], i=0, divisor=100000, soma=0;

    while(conta >= 1){
        // Separando numero por numero
        numero[i] = conta/divisor;
        // Pegando o resto e transformando em inteiro para depois tirar outro número.
        conta = conta % divisor;
        // Diminuindo o divisor para separa o próximo número.
        divisor = divisor / 10;
        // Somando os números individuais.
        soma = soma + numero[i];
    }
    return (soma % 10);
}

int main(){
    setlocale(LC_ALL,""); // Trocando Idioma: Português.
    SetConsoleTitle("Gerador de Digito Verificador - Desenvolvido por: Vinicius Carvalho - 74.381"); // Título do Programa.
    Cabecalho();

    // Variável.
    int conta;

    // Entrada de Dados
    while(conta <= 0 || conta >= 1000000){
        printf("\n\n > Digite o Numero de sua Conta: ");
        scanf("%d", &conta);
    }

    printf("\n\n\t\t\t=================================");
    printf("\n\t\t\t| > Numero da Conta: %06d-%d < |", conta, Gerador_DV(conta));
    printf("\n\t\t\t=================================\n\n");
    getch();
    return 0;
}

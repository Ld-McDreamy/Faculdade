#include <stdio.h>
#include <stdlib.h>
#include <locale.h> // Trocar o Idioma;
#include <windows.h> // Colocar T�tulo;

/*
O perfil de uma pessoa pode ser determinado a partir da sua data de nascimento, conforme
exemplificado a seguir. Dada uma data de nascimento, entrando com Dia, M�s e Ano, apresente
como sa�da o perfil correspondente.
*/

void Cabecalho(){
    system("cls");
    system("color 3");

    // Cabe�alho com Nome, R.A. e Campus.
    printf("  Desenvolvido por: Vinicius Carvalho ---- 74.381 ---- UNASP-HT  \n");
    printf("------------------------------------------------------------------\n");
    // T�tulo do Programa.
    printf("\n\t===============================================================\n");
    printf("\t|                  Descubra o Seu Perfil                      |\n");
    printf("\t===============================================================\n");
}

int Processamento_Perfil(int d, int m, int a){
    int parte_1, resultado, parte_2Aux;

    // Juntando DIA e M�S, Somando com o ano:
    parte_1 = ((d * 100) + m) + a;
    // Pegando os dois primeiros digitos:
    parte_2Aux = (parte_1/100);
    // Pegando os dois �ltimos digitos:
    resultado = parte_2Aux + (parte_1-(parte_2Aux*100));

    return(resultado);
}

int main(){
    setlocale(LC_ALL,""); // Trocando Idioma: Portugu�s.
    SetConsoleTitle("Descubra seu Perfil"); // T�tulo do Programa.
    Cabecalho();

    int dia, mes, ano, perfil;

    printf("\n > Digite o DIA do seu nascimento: ");
    scanf("%i", &dia);
    printf("\n > Digite o M�S do seu nascimento: ");
    scanf("%i", &mes);
    printf("\n > Digite o ANO do seu nascimento: ");
    scanf("%i", &ano);

    perfil = Processamento_Perfil(dia, mes, ano);
    system("cls");

    switch(perfil % 5){
        case 0:
            Cabecalho();
            printf("\n\n\t\t\t ++++++++++++++++++++++++++");
            printf("\n\t\t\t + O seu Perfil �: T�MIDO +");
            printf("\n\t\t\t ++++++++++++++++++++++++++\n\n");
            break;
        case 1:
            Cabecalho();
            printf("\n\n\t\t\t ++++++++++++++++++++++++++++");
            printf("\n\t\t\t + O seu Perfil �: SONHADOR +");
            printf("\n\t\t\t ++++++++++++++++++++++++++++\n\n");
            break;
        case 2:
            Cabecalho();
            printf("\n\n\t\t\t ++++++++++++++++++++++++++++++");
            printf("\n\t\t\t + O seu Perfil �: PAQUERADOR +");
            printf("\n\t\t\t ++++++++++++++++++++++++++++++\n\n");
            break;
        case 3:
            Cabecalho();
            printf("\n\n\t\t\t ++++++++++++++++++++++++++++");
            printf("\n\t\t\t + O seu Perfil �: ATRAENTE +");
            printf("\n\t\t\t ++++++++++++++++++++++++++++\n\n");
            break;
        case 4:
            Cabecalho();
            printf("\n\n\t\t\t ++++++++++++++++++++++++++++++++");
            printf("\n\t\t\t + O seu Perfil �: IRRES�STIVEL +");
            printf("\n\t\t\t ++++++++++++++++++++++++++++++++\n\n");
            break;
    }

    getch();
    return 0;
}
